# Compiler-PCL


Compuesto de los siguientes componentes:

Scanner: Componente del Scanner para un compilador del lenguaje ficticio PCL. Proyecto 1 del curso de Compiladores e Intérpretes.
Realizado en lenguaje Java y con la utilización de la biblioteca JFlex.
